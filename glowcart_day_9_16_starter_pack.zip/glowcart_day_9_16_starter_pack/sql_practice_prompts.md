# GlowCart SQL Practice Prompts

Import `dirty_orders_v2.csv` and `product_lookup.csv` into your SQL tool, then try these.

1. Show all rows where `order_status` looks like a return or cancellation.
2. Sort orders by `unit_price` from highest to lowest.
3. Count how many rows have missing `region`, `channel`, or `order_status`.
4. Find duplicate rows by grouping on the columns that should define a unique order line.
5. Standardize region names using a `CASE` expression into `North`, `South`, `East`, `West`.
6. Standardize channel names into `Search`, `Social`, `Email`, `Direct`, `Affiliate`.
7. Join `dirty_orders_v2` to `product_lookup` on `product_id` and identify unmatched product IDs.
8. Calculate revenue by region after standardizing region names.
9. Show any rows with suspicious values such as negative `unit_price`, zero `units`, or unusually high `discount_pct`.
10. Count orders by standardized status.
11. Find the average rating by standardized region.
12. Create a cleaned view or temporary table that trims whitespace from product IDs and normalizes key fields.

## Minimum challenge set
At minimum, do:
- one filtering task
- one sorting task
- one join
- one duplicate-related task
- one cleaning or standardization task
- one aggregation task