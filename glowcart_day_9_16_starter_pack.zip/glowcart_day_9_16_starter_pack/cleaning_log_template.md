# GlowCart Cleaning Log Template

Use one row per issue type or fix.

| Issue ID | Dataset | Problem found | Example row or value | How I fixed it | What I could not fully fix | Reviewer notes |
|---|---|---|---|---|---|---|
| 1 | dirty_orders_v2.csv | | | | | |
| 2 | dirty_orders_v2.csv | | | | | |
| 3 | customer_feedback_dirty.csv | | | | | |
| 4 |  | | | | | |
| 5 |  | | | | | |

## Quick reminders
- Do not overwrite raw files without keeping a clean version or a note.
- If you guessed, say you guessed.
- If you could not fix something safely, flag it instead of making up data.