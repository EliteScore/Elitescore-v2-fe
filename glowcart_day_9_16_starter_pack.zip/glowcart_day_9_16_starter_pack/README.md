# GlowCart Day 9–16 Starter Pack

Use this pack for the messy-data and cleaning stretch.

## Files
- `dirty_orders_v2.csv`
- `product_lookup.csv`
- `customer_feedback_dirty.csv`
- `data_quality_checklist.md`
- `cleaning_log_template.md`
- `sql_practice_prompts.md`
- `README.md`

## How to use it
1. Keep using the same spreadsheet workbook from Days 1–8.
2. Import these new CSVs into new tabs.
3. Pick one SQL tool and stick with it:
   - BigQuery Sandbox
   - DB Browser for SQLite
   - SQLiteOnline
   - DuckDB
4. Clean carefully and log your changes. Do not silently “fix” things and then forget what happened.

## Intentional messes in this pack
Yes, some values are ugly on purpose:
- mixed region names
- mixed date formats
- duplicate rows
- blank cells
- unmatched product IDs
- weird status labels
- suspicious values

That is the whole point. Welcome to analyst life.