# GlowCart Data Quality Checklist

Use this as a first-pass review for `dirty_orders_v2.csv`.

## Structure
- [ ] Do the columns match what you expected?
- [ ] Does one row still represent one order line?
- [ ] Are there duplicate rows?

## Completeness
- [ ] Are any important fields missing?
- [ ] Are there missing prices, regions, statuses, or product IDs?
- [ ] Are ratings missing more often for certain rows?

## Consistency
- [ ] Are region names written consistently?
- [ ] Are channel names written consistently?
- [ ] Are status labels standardized?
- [ ] Are dates stored in one format?

## Validity
- [ ] Are units positive integers?
- [ ] Are prices non-negative?
- [ ] Are discounts in a sensible range?
- [ ] Do product IDs match the lookup file?

## Reasonableness
- [ ] Are there suspiciously high discounts?
- [ ] Are there rows with zero units or negative prices?
- [ ] Do summary totals look believable?

## Documentation
- [ ] Did you record what you changed?
- [ ] Did you flag anything you could not safely fix?
- [ ] Could someone else reproduce your cleaning steps?