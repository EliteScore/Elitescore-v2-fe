# GlowCart Day 1–8 Starter Pack

Use this pack for the first 8 days of the Google Data Analytics challenge.

## Files
- `orders_raw.csv`
- `campaign_spend.csv`
- `product_catalog.csv`
- `customer_summary.csv`
- `data_dictionary.md`
- `business_questions.txt`
- `README.md`

## How to use it
1. Create one main workbook in Google Sheets or Excel.
2. Import each CSV into a separate tab.
3. Keep your written answers in Google Docs, Word, or Notion.
4. Do not overcomplicate the setup. The point here is to learn how to inspect data, ask better questions, and get comfortable working in a spreadsheet.

## Best starting tab
Start with `orders_raw.csv`, then look at `campaign_spend.csv` for channel and spend questions.

## Notes
- One row in `orders_raw.csv` represents one order line.
- The data is mostly clean on purpose so early days focus on thinking and basic spreadsheet work, not firefighting.