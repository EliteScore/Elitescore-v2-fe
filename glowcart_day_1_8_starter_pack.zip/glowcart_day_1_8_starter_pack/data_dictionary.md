# GlowCart Data Dictionary

## orders_raw.csv
One row = one order line.

- `order_id`: unique order identifier
- `order_date`: order date in YYYY-MM-DD format
- `customer_id`: customer identifier
- `region`: customer region (`North`, `South`, `East`, `West`)
- `channel`: acquisition or marketing channel (`Search`, `Social`, `Email`, `Direct`, `Affiliate`)
- `product_id`: product identifier
- `product_name`: product name
- `category`: product category
- `units`: number of units in the order line
- `unit_price`: price per unit before discount
- `discount_pct`: discount applied to the order line
- `gross_revenue`: `units * unit_price`
- `net_revenue`: gross revenue after discount
- `estimated_margin_usd`: simplified estimated margin for practice
- `order_status`: `Completed`, `Returned`, or `Cancelled`
- `is_returned`: 1 if returned, 0 otherwise
- `customer_rating`: post-purchase rating, when available
- `payment_method`: payment method used
- `device_type`: device used at checkout

## campaign_spend.csv
One row = one month x region x channel spend record.

- `month`: calendar month in YYYY-MM format
- `region`: region tied to the campaign performance
- `channel`: marketing channel
- `spend_usd`: ad spend
- `impressions`: ad impressions
- `clicks`: ad clicks
- `conversions`: tracked conversions

## product_catalog.csv
One row = one product.

- `product_id`: product identifier
- `product_name`: product name
- `category`: product category
- `base_price`: standard price
- `is_active`: 1 if active in catalog
- `supplier_name`: supplier or vendor
- `avg_product_rating`: average rating at product level

## customer_summary.csv
One row = one customer summary.

- `customer_id`: customer identifier
- `customer_name`: fake customer name
- `region`: customer region
- `signup_date`: customer signup date
- `segment`: simple customer segment (`New`, `Repeat`, `VIP`)
- `lifetime_orders`: total number of orders
- `lifetime_spend`: total net revenue from the customer
- `avg_rating`: average rating given by the customer
- `last_order_date`: most recent order date

## Suggested beginner questions
- Which region has the most orders?
- Which channel has the highest spend?
- Which category brings the most revenue?
- Is higher spend always linked to more conversions?
- Which customer segment seems most valuable?