# GlowCart Day 17–25 Starter Pack

Use this pack for the analysis, dashboard, and R stretch.

## Files
- `cleaned_glowcart_orders.csv`
- `customer_snapshot.csv`
- `monthly_region_revenue.csv`
- `dashboard_brief.md`
- `chart_selection_worksheet.md`
- `tableau_storyboard_template.md`
- `r_starter_script.R`
- `ggplot_prompt_sheet.md`
- `rmarkdown_report_template.Rmd`
- `presentation_outline.md`
- `presentation_feedback_checklist.md`
- `README.md`

## How to use it
1. Keep using the same GlowCart workbook.
2. Import the new CSVs into new tabs or your SQL tool.
3. Use `cleaned_glowcart_orders.csv` as the main analysis table.
4. Use `monthly_region_revenue.csv` as a cross-check file.
5. Use the markdown templates for dashboard planning and final communication.
6. Install R and RStudio only when you actually reach the R section, unless you already use Colab or another notebook tool.

## Main analysis idea
The raw mess is over. Now the job is to:
- explore
- aggregate
- compare
- visualize
- tell a business story
- recommend action