# GlowCart R starter script
# Goal: load the cleaned dataset, inspect it, summarize it, and make one basic plot.

library(readr)
library(dplyr)
library(ggplot2)

orders <- read_csv("cleaned_glowcart_orders.csv")

# Quick inspection
glimpse(orders)
summary(orders)

# Simple grouped summary
region_summary <- orders %>%
  group_by(region) %>%
  summarise(
    total_orders = n_distinct(order_id),
    total_revenue = sum(net_revenue, na.rm = TRUE),
    avg_rating = mean(customer_rating, na.rm = TRUE),
    return_rate = mean(is_returned, na.rm = TRUE)
  ) %>%
  arrange(desc(total_revenue))

print(region_summary)

# Monthly revenue summary
monthly_summary <- orders %>%
  group_by(month) %>%
  summarise(total_revenue = sum(net_revenue, na.rm = TRUE))

print(monthly_summary)

# Basic plot
ggplot(monthly_summary, aes(x = month, y = total_revenue, group = 1)) +
  geom_line() +
  geom_point() +
  labs(
    title = "GlowCart Monthly Revenue",
    x = "Month",
    y = "Total Revenue"
  )