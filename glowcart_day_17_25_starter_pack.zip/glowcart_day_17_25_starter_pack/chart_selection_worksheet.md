# Chart Selection Worksheet

Copy this structure for each chart you plan.

## Chart 1
- Business question:
- Fields used:
- Chart type:
- Why this chart fits:
- What could mislead the viewer if done badly:

## Chart 2
- Business question:
- Fields used:
- Chart type:
- Why this chart fits:
- What could mislead the viewer if done badly:

## Chart 3
- Business question:
- Fields used:
- Chart type:
- Why this chart fits:
- What could mislead the viewer if done badly:

## Chart 4
- Business question:
- Fields used:
- Chart type:
- Why this chart fits:
- What could mislead the viewer if done badly:

## Chart 5
- Business question:
- Fields used:
- Chart type:
- Why this chart fits:
- What could mislead the viewer if done badly: