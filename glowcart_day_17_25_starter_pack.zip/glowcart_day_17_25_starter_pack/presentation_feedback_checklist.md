# Presentation Feedback Checklist

Use this to review your final output.

- [ ] Is the business question clear?
- [ ] Do the charts answer real questions?
- [ ] Are the labels readable and honest?
- [ ] Does each claim link back to actual data?
- [ ] Did you avoid dumping random metrics?
- [ ] Is the recommendation specific?
- [ ] Did you mention at least one limitation or caveat?
- [ ] Could a stakeholder understand the story quickly?