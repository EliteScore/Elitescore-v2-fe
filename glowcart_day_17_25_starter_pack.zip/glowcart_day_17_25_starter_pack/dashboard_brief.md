# GlowCart Dashboard Brief

## Audience
GlowCart leadership team:
- founder
- marketing lead
- operations lead

## Goal
Build a simple business-facing dashboard that helps leadership understand:
1. where revenue is coming from
2. which channels and regions matter most
3. where returns or customer experience issues might be hurting growth

## Suggested KPIs
- total revenue
- total orders
- average order value
- return rate
- average customer rating

## Suggested views
- monthly revenue trend
- revenue by region
- revenue by channel
- sales by category
- customer rating or return-related view

## Important reminder
Do not make a pretty nonsense dashboard.
Every chart should answer a real question.