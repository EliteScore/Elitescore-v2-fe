# Tableau Storyboard Template

## Slide / View 1 — What is happening?
- Main takeaway:
- Supporting metric:
- Supporting chart:

## Slide / View 2 — Why does it matter?
- Operational or commercial impact:
- Who should care:
- Supporting evidence:

## Slide / View 3 — Where is the strongest signal?
- Region / channel / category / customer segment:
- Supporting metric:
- Supporting chart:

## Slide / View 4 — What should GlowCart do next?
- Recommendation:
- Expected benefit:
- Risk or tradeoff:

## Keep the story tight
Try to connect three key findings instead of dumping every metric you made.