# GlowCart Presentation Outline

## 1. Business question
What were you trying to answer?

## 2. Data used
Which files supported the analysis?

## 3. Key findings
- Finding 1
- Finding 2
- Finding 3

## 4. Recommendation
What should GlowCart actually do next?

## 5. Risks or caveats
What should leadership not overinterpret?

## 6. Next steps
What additional analysis would strengthen the decision?