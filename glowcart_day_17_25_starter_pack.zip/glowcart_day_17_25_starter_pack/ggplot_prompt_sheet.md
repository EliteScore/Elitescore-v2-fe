# ggplot Prompt Sheet

Use these if you want chart ideas for the final stretch.

1. Make a line chart of monthly revenue.
2. Make a bar chart of revenue by region.
3. Make a bar chart of revenue by channel.
4. Make a category-level sales chart.
5. Make a chart that compares return rate across regions or channels.
6. Make a chart that shows average customer rating by category.
7. Improve one chart with:
   - better axis labels
   - a useful title
   - cleaner theme choices
   - an annotation or highlight
8. Build one chart that supports a recommendation, not just a description.