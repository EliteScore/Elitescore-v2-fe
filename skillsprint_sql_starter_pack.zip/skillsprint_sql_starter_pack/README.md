# SkillSprint SQL Starter Pack

This pack is meant for the **EliteScore SQL & Database Design** challenge based on **CS50's Introduction to Databases with SQL**.

## What's inside

- `skillsprint_schema.sql` — creates the starter tables
- `skillsprint_seed.sql` — loads realistic sample data
- `skillsprint_starter.db` — ready-to-use SQLite database with the schema + data already loaded
- `verify_setup.sql` — a tiny setup check

## Quick start

### Option 1: safest setup in SQLite Online
1. Open SQLite Online.
2. Run `skillsprint_schema.sql`.
3. Run `skillsprint_seed.sql`.
4. Run:
   ```sql
   SELECT * FROM courses_feed LIMIT 5;
   ```

### Option 2: direct import
If your SQLite tool supports importing a `.db` file, import `skillsprint_starter.db` directly.

## Table plan by challenge stage

### Days 1–3
Use `courses_feed`.

This table acts like a course catalog and is built for:
- `SELECT`
- `LIMIT`
- `WHERE`
- `IS NULL`
- `LIKE`
- `ORDER BY`
- `COUNT`, `AVG`, `MIN`, `MAX`

It contains:
- free and paid courses
- multiple categories and levels
- some missing values for `IS NULL` practice
- enough rows to sort, filter, and summarize properly

### Days 4–6
Use:
- `users`
- `courses`
- `lessons`
- `enrollments`

This part is designed for:
- relationships
- primary and foreign keys
- joins
- grouped summaries
- subqueries
- set logic
- real platform-style questions

### Day 7
Use `messy_courses`.

This table is intentionally messy and denormalized so learners can inspect:
- duplicated course info
- repeated instructor info
- repeated learner info
- mixed certificate wording
- why normalization matters

### Day 8 onward
Keep using the same database and improve it:
- add better constraints
- create new tables
- build views
- add indexes
- write transactions
- optimize queries
- turn it into a final project

## Suggested starter checks

```sql
SELECT * FROM courses_feed LIMIT 5;

SELECT category, COUNT(*) AS total_courses
FROM courses_feed
GROUP BY category
ORDER BY total_courses DESC;

SELECT c.title, COUNT(e.enrollment_id) AS enrollments
FROM courses c
LEFT JOIN enrollments e ON e.course_id = c.course_id
GROUP BY c.course_id, c.title
ORDER BY enrollments DESC, c.title;
```

## Notes

- The data is small enough for beginners to understand, but varied enough to feel real.
- Dates are stored as text in SQLite-friendly format.
- Booleans are stored as `0` and `1`, because SQLite does SQLite things and likes chaos.

Good luck. Make the queries suffer a little.