PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS messy_courses;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS lessons;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS courses_feed;

CREATE TABLE courses_feed (
    feed_course_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    instructor_name TEXT,
    provider TEXT NOT NULL,
    category TEXT NOT NULL,
    level TEXT NOT NULL CHECK (level IN ('Beginner', 'Intermediate', 'Advanced')),
    price_usd REAL NOT NULL CHECK (price_usd >= 0),
    rating REAL CHECK (rating BETWEEN 0 AND 5),
    reviews_count INTEGER NOT NULL CHECK (reviews_count >= 0),
    duration_hours REAL NOT NULL CHECK (duration_hours > 0),
    language TEXT,
    certificate_available INTEGER NOT NULL DEFAULT 0 CHECK (certificate_available IN (0, 1)),
    published_at TEXT,
    last_updated TEXT,
    seats INTEGER CHECK (seats IS NULL OR seats > 0),
    format TEXT NOT NULL CHECK (format IN ('Self-paced', 'Cohort', 'Live', 'Hybrid')),
    slug TEXT NOT NULL UNIQUE
);

CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    country TEXT,
    joined_at TEXT NOT NULL,
    career_stage TEXT NOT NULL CHECK (career_stage IN ('student', 'career-switcher', 'professional'))
);

CREATE TABLE courses (
    course_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    instructor_name TEXT NOT NULL,
    price_usd REAL NOT NULL CHECK (price_usd >= 0),
    rating REAL CHECK (rating BETWEEN 0 AND 5),
    level TEXT NOT NULL CHECK (level IN ('Beginner', 'Intermediate', 'Advanced')),
    status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'archived')),
    seat_limit INTEGER CHECK (seat_limit > 0),
    created_at TEXT NOT NULL
);

CREATE TABLE lessons (
    lesson_id INTEGER PRIMARY KEY,
    course_id INTEGER NOT NULL,
    lesson_number INTEGER NOT NULL CHECK (lesson_number > 0),
    title TEXT NOT NULL,
    duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
    is_preview INTEGER NOT NULL DEFAULT 0 CHECK (is_preview IN (0, 1)),
    published_at TEXT,
    UNIQUE (course_id, lesson_number),
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE enrollments (
    enrollment_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    enrolled_at TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'completed', 'dropped', 'paused')),
    progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
    completed_at TEXT,
    UNIQUE (user_id, course_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE messy_courses (
    row_id INTEGER PRIMARY KEY,
    course_title TEXT,
    category TEXT,
    instructor_name TEXT,
    instructor_email TEXT,
    lesson_title TEXT,
    lesson_duration_minutes INTEGER,
    student_name TEXT,
    student_email TEXT,
    student_country TEXT,
    enrollment_status TEXT,
    price_usd REAL,
    platform TEXT,
    course_rating REAL,
    certificate_text TEXT
);