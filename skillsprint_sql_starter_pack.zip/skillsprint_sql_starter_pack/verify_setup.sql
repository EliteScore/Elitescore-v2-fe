PRAGMA foreign_keys = ON;

SELECT * FROM courses_feed LIMIT 5;

SELECT COUNT(*) AS courses_feed_rows FROM courses_feed;
SELECT COUNT(*) AS users_rows FROM users;
SELECT COUNT(*) AS courses_rows FROM courses;
SELECT COUNT(*) AS lessons_rows FROM lessons;
SELECT COUNT(*) AS enrollments_rows FROM enrollments;
SELECT COUNT(*) AS messy_courses_rows FROM messy_courses;